# Frozen scientific specification: public extract

This standalone specification restates the scientific definitions used by the accepted analysis. It is an extract from the frozen analysis plan and measurement decisions, with administrative history/local pointers removed. It is not a new registration, a revised hypothesis, or a claim of data-naive work. The source sample received prior technical processing (profiles, reliability/covariance diagnostics, short-form CFAs, validation SEM and five-composite OLS); those did not test this full-first-order interaction contrast. The original plan was prospectively posted in GitHub commit 20b0cd92de4a08f0b47649183cef92e690026ef6 before the new-study tests. Exact ancestral hashes and the public extract hash are in provenance.json. The accepted original scientific findings were independently reproduced across all six analyses. This packaging revision requires a separate narrow portability review.

Question: does perceived nonavailability of needed digital technologies amplify the association of performance monitoring with later exhaustion more than it amplifies the association of privacy intrusion? The directly described population is the released German validation sample: 1,560 people; digital hindrance stressors measured March 2019 and exhaustion May 2020. One row is one person. This is a between-person lagged conditional association. Individual wave dates, baseline exhaustion, organization keys, baseline-only attriters and assignment are unavailable. No recruitment, pooling, weighting or holdout split occurs. Only the pinned sample-3 CSV version 1 described in SOURCE.md is eligible.

## 3. Eligibility and validation rules

1. Verify source hash before parsing. Treat the source R scripts as documentation; do not run their install/load/download directives or inherit their score calculations.
2. Require the documented sample-3 fields, 60 items, age, gender and label, and a unique nonmissing within-file ID. Expected source dimensions are 1,560 rows/71 fields. A discrepancy, duplicate ID, inconsistent numeric/label mapping, unexpected item code or failed hash stops dependent analysis for documented resolution; do not delete duplicates or force agreement. Additional irrelevant columns are not used.
3. Item validation, missingness, means and the full map are fixed in the measurement section below. No item or person exclusion based on exhaustion level, residuals, multivariate outliers, response uniformity or later significance. Preserve valid extreme responses.
4. Primary cohort: all rows complete on 60 items plus valid age/gender. Age must be finite and in the physically plausible interval 0–120 years; values outside it are source errors to resolve rather than automatic exclusions. A value inconsistent with adult employment is flagged and resolved from source documentation before analysis, not silently corrected. Unknown demographics are missing, not guessed. Report a transparent flow from release rows through validation to eligible rows.
5. If a required score SD is zero, the primary contrast is undefined. If the model is rank-deficient for the target contrast, residual degrees of freedom are below 200, or a leverage value is at least 0.99, do not replace the primary estimator with a simpler significant model. Report primary nonestimability and the reason; any replan needs a fresh prospective version and is no longer the original test.

Complete-case results concern that cohort. No assertion of missing-at-random or correction for attrition follows. The prorating sensitivity is compulsory if incomplete item rows exist. Missingness or data-validation decisions are logged as actual post-posting exposure; they must not become unreported hypothesis changes.

## 4. Variables, estimand and theory restrictions

Use the 12 published first-order mean scores in this fixed order: INV, OVE, COM, INS, UNC, UNR, ROL, IOP, INT, PER, NON, LSA. Standardize the completed scale means to Z_j; standardize the mean of EMO01–09 to Y. Let A=Z_NON, M=Z_PER, P=Z_IOP. No other outcome is primary or secondary.

For the release population defined above, the estimand is the coefficient contrast in the least-squares projection of standardized later exhaustion onto the fixed quadratic feature basis and demographic adjustment. It is well-defined as an observed-score association even if the conditional mean is not exactly quadratic. A process interpretation additionally requires that the functional approximation is adequate and that alternative confounding/measurement explanations are sufficiently limited; the design cannot establish the latter.

Fit:

`Y = alpha + sum_j b_j Z_j + sum_j q_j Z_j^2 + sum_{j<k} g_jk Z_j Z_k + c1 Age10 + c2 Age10^2 + gender indicators + error`

where Age10=(age−sample mean age)/10. The model includes 12 first-order terms, 12 own-squares and **all 66 distinct pair products**, plus intercept/demographics. Typical male/female coding gives 94 fitted columns and 1,466 residual degrees of freedom if n=1,560 and full rank. All stressor terms stay regardless of their estimates or significance. This is a descriptive adjustment for co-occurrence, not a claim that simultaneous stressors are a valid causal control set.

Primary specificity contrast: `theta = g_NON,PER − g_NON,IOP`. Required companion: `gamma = g_NON,PER`. Let S=(M+P)/2 and D=(M−P)/2. Theta is the A×D coefficient: how the monitoring-versus-privacy profile contrast changes with nonavailability, keeping S and the other scores fixed. In the quadratic model it is also the difference between mixed partial derivatives with respect to A,M and A,P.

For an interpretable illustration, consider A=−0.5 versus +0.5 and two surveillance profiles `(M,P)=(+0.5,−0.5)` versus `(−0.5,+0.5)`, with other Z values at zero and common demographics. The difference in the two profiles' exhaustion difference between the two A levels equals theta outcome SD. The separate four-corner A×M difference with P and other scores fixed equals gamma. These are modeled between-person profile contrasts, not intervention predictions.

**H1 (conjunctive signature): gamma>0 and theta>0.** Both must be supported. Positive theta alone is insufficient if it arises only from a negative A×P association. **Practical target:** delta=0.20 outcome SD for theta's declared profile contrast. This margin is an explicitly chosen research threshold for consequential diagnostic differentiation, not a validated clinical minimum. Continuous intervals remain central; smaller effects may still be interesting but cannot be called consequential at this margin.

Rival R1: all pair interactions zero (additive heterogeneous demands, allowing own-curvature); it predicts gamma=theta=0. Rival R2: A interacts with S but not D (undifferentiated surveillance complementarity); it allows gamma>0 but predicts theta=0. Equal-weight quadratic total standardized burden also predicts equal pair cross-coefficients and theta=0. These restrictions are not attributed to the seed. Unequally weighted latent burden, differential measurement error or unmeasured common causes need not obey theta=0 and remain alternatives even if H1 is supported.

## 5. Estimation, uncertainty and multiplicity

**Estimator choice.** A five-domain regression cannot separate performance monitoring from privacy intrusion; a purely additive twelve-score model cannot test the proposed contingency. A reduced three-score interaction model would be more precise but could assign omitted cross-curvature from other demands to the focal pair. The full quadratic is selected before outcomes to allow every such second-order term. A latent moderated structural model could address measurement error under additional distributional and measurement assumptions, but would target a different latent estimand, require a substantially more complex interaction measurement model, and still would not identify accountability or remove prior-exhaustion confounding. We therefore deliberately target transparent observed-score contrasts, retain full scales and prespecified measurement sensitivities, and bound conclusions accordingly. No data-driven estimator competition, penalized variable selection, factor-score substitution, or automatic migration to a latent model is planned. Failure of the observed-score design is a failure/replan, not permission to switch estimands.

Fit ordinary least squares using stable QR/SVD numerical linear algebra. Estimate a heteroskedasticity-robust HC3 covariance and report gamma, theta, their covariance, standard errors and two-sided 95% t intervals with n−rank degrees of freedom. HC3 is a diagnostic cross-check; **the prespecified primary intervals are respondent-pairs bootstrap percentile intervals**, which re-estimate standardization and the model in each resample.

Bootstrap: exactly 1,999 resamples of n persons with replacement; deterministic seed 2026102305; no cluster resampling because no cluster key is available. Within each replicate recompute all sample means/SDs, age centering, all polynomial terms and the fit; retain a replicate only if required score SDs are positive and gamma/theta are estimable. Gender factor levels are fixed to the original eligible set; an absent category's all-zero nuisance column may be omitted within a replicate. Do not replace failed draws with extra draws. At least 1,900 valid draws are required for primary bootstrap intervals; otherwise report failure and HC3 results as sensitivity only. Use the empirical quantile definition equivalent to R type=7 / NumPy linear. Report invalid draw counts and reasons, seeds and software versions. Record all raw-data processing locally; do not publish sampled rows.

Primary 95% intervals use percentiles 2.5 and 97.5; the equivalence interval for theta uses percentiles 5 and 95. The latter is the interval form of two one-sided tests at alpha .05, with the usual bootstrap approximation. H1 support requires both 95% lower limits greater than zero. This is an intersection–union claim: both component conditions must pass; no family of 66 discovered interactions is tested. Requiring two 95% intervals is conservative for the directional conjunction. Do not treat nuisance pair coefficients as a discovery family, rank significant ones, or promote them to hypotheses.

A consequential specificity claim requires theta's 95% lower limit >0.20 **and** gamma's 95% lower limit >0. Report as positive but not established consequential when H1 passes but this stronger rule fails. Evidence against materially positive specificity is theta's 95% upper limit <0.20. Equivalence at the declared margin requires the entire 90% interval inside [−0.20,+0.20]; it does not establish literal equality or equivalence of latent constructs. A 95% upper limit <0 contradicts the predicted ordering. Wide intervals mean inconclusive. All classification rules are reported, not selected post hoc. No p-value is required to report the interval-based primary decision.

All robustness analyses concern this same prespecified contrast, are reported jointly, and cannot replace a failed primary result. No separate confirmatory claim is drawn from their nominal intervals. Any other outcome, subgroup, selected pair interaction, new item subset, new latent profile or adaptive prediction analysis is explicitly exploratory and outside the planned primary article.

## 6. Support, diagnostics and compulsory sensitivity analyses

**Support before interpretation.** Report sample size, scale distributions, PER–IOP correlation, focal three-dimensional support, standardized design condition number, rank, residualized contrast information, leverage and robust/bootstrapped interval widths. For the illustrative theta profiles, count observations in each of four disjoint cubes: A in [−1,0) or [0,1], and either M in [0,1], P in [−1,0) or M in [−1,0), P in [0,1]. Counts refer only to the three focal scores, so they do not prove overlap in all 12 dimensions. Require at least 25 respondents in each cube before labeling the illustrated moderate profiles empirically supported. Otherwise retain the projection estimate but label the profile interpretation support-limited; do not relocate the profiles to prettier quantiles. Also give background-score ranges/standardized differences across cubes without claiming exchangeability. Suppress public subgroup tables if they permit identifying combinations; these focal counts need contain no demographic linkage.

**Numerical diagnostics.** Report a condition number after scaling every nonconstant model column to unit SD; >1e8 is a numerical-instability flag requiring independently checked linear algebra before any inferential conclusion. A large but estimable SE is substantive weak information, not justification to remove covariates/interactions. Plot residual-versus-fitted and observed-versus-fitted distributions; record predictions outside the possible exhaustion range after back-transformation. These plots diagnose model limitations, not a model-selection tournament.

Perform these fixed sensitivities regardless of primary significance, unless explicitly conditional below:

1. **Units.** Refit using all 12 unstandardized 0–4 scale means centered at their primary means, with the same outcome standardization and full quadratic specification. Report the corresponding theta/gamma per one response-unit changes. It addresses whether the primary ordering depends on different SD units. Do not apply the standardized 0.20 margin to this different unit. A sign reversal limits the claim to the original standardized comparison.
2. **Published item-loadings.** Replace the mean for each of the three focal scales with the sum of item×published standardized loading divided by the sum of loadings, then standardize and refit the full model; keep background and outcome means unchanged. Weights from Supplement Table 22 are NON=(.83,.83,.82,.90,.84,.84), PER=(.78,.80,.88,.83,.87,.79), IOP=(.93,.95,.92), in their stated code order. This is a prespecified measurement sensitivity, not an error-free factor estimate; the loadings come from the already published same source sample and are not independent validation. No weights are refitted to exhaustion.
3. **Functional form.** Add all ten distinct total-degree-three monomials in (A,M,P), plus T^3 and T^4 where T is the mean of the 12 standardized scores. Keep every primary term. Evaluate the **same four-profile finite contrast** for theta, and the A×M four-corner contrast at ±0.5 with P=0 for gamma, using predictions and recomputing these contrasts in the bootstrap. This preserves the interpretive target when curvature is no longer constant. T is a transparent equal-weight burden summary, not the original DHS latent score. It challenges cubic focal and higher total-burden curvature but cannot eliminate every functional-form rival.
4. **Influence.** Refit the primary specification after excluding rows with primary leverage h_i>3p/n, where p is fitted rank, then recompute scaling. Report the number removed and both contrasts. This deterministic influence sensitivity does not replace the inclusive primary cohort; genuine extreme observations remain in the primary estimate. Do not identify individual cases in released outputs.
5. **Demographic specification.** Refit without age/gender. This shows dependence on their uncertain variable-specific timing and on descriptive adjustment; it does not establish causal robustness.
6. **Incomplete-item scoring.** If any item-incomplete respondents exist, run the fixed 80% per-scale prorating sensitivity from the measurement decisions. No outcome-dependent missing-data model or imputation search.

Use the same 1,999-draw bootstrap algorithm/seed for sensitivities, with each analysis cohort's size and scaling, and report their valid-draw counts. A robust-score variant failing estimation is reported as failed, not silently omitted. For all analyses, if resampling demonstrates expensive computation, retain the specified draw count; report interruption rather than reduce it after seeing results.

The theoretical interpretation is **fragile** if theta or gamma changes sign in any required estimable sensitivity, if the primary H1 classification fails under the functional-form sensitivity, or if support requirements fail. Loss of nominal significance in smaller sensitivity samples alone is not a sign reversal and is reported with interval widths. Agreement does not resolve prior exhaustion, differential measurement error, common reporting dispositions, occupation, job control or pandemic-related change. There is no validated negative control or instrument in these data.

## 7. Missingness, dependence, selection and generalization

Missing-item/covariate losses, release selection and follow-up attrition are distinct. Report known denominators and unknown baseline attrition explicitly; do not infer a response rate from the released complete sample. Complete-case and prorating estimands are different, so differences may reflect selection as well as scoring. There is no released basis for inverse-probability correction of baseline attrition. Bootstrap/HC3 assume independent people; recruitment through a panel does not establish organization-level independence. No cluster IDs or weights will be invented. Hidden clustering can make intervals too narrow and remains an explicit limitation.

Standardized mean scores are fallible ordinal-item summaries. Arithmetic means are fixed operationalizations, not proof of interval latent measurement. The same questionnaire wave measures the 12 stressors, and stable negative affect or prior exhaustion can generate both main and interaction associations. A 14-month lag does not remove these alternatives. A result pertains to the sampled German digital workers and historical period; no prevalence or policy-benefit estimate for today's workforce follows.

## 8. Fixed-data precision and stopping

Sample size is fixed by the pinned release; no optional stopping or addition of another source sample. The frozen design included analytic, metadata-only precision scenario calculations, including a covariance constructed from published hierarchy/loadings under explicit normality and reliability assumptions. They are not new empirical estimates or observed power. At documented n=1,560 they indicate reasonable resolution for some moderate specificity contrasts and poor resolution under high collinearity. Neither a detectable-effect calculation nor the known aggregate DHS–exhaustion association guarantees H1 power. No sample split is created to simulate independence or to make an unexposed holdout claim.

Failed support, nonestimability, wide intervals and null results remain reportable outcomes of the frozen plan. Do not search other pairs to rescue publishability.


## Measurement details

## Instrument and exact maps

Use the established **extensive sample-3 first-order scales**, expressed as manifest arithmetic means. These are transparent observed scores, not estimated latent factor scores, the seed's third-order DHS parameter, or a newly validated psychometric scale. Use all original items within every scale; no outcome-based item selection or reliability-based deletion.

| Symbol/code | Items | Role |
|---|---|---|
| INV | INV01, INV02, INV03 | Background first-order demand |
| OVE | OVE01, OVE02, OVE03, OVE04 | Background demand |
| COM | COM01, COM02, COM03, COM04, COM05 | Background demand |
| INS | INS01, INS02, INS03, INS04 | Background demand |
| UNC | UNC01, UNC02, UNC03, UNC04 | Background demand |
| UNR | UNR01, UNR02, UNR03 | Background demand |
| ROL | ROL01, ROL02, ROL03, ROL04 | Background demand |
| IOP / P | IOP02, IOP03, IOP04 | Focal privacy intrusion comparator |
| INT | INT01, INT02, INT03 | Background demand |
| PER / M | PER01, PER02, PER03, PER04, PER05, PER06 | Focal performance monitoring |
| NON / A | NON01, NON02, NON03, NON04, NON05, NON06 | Focal nonavailability |
| LSA | LSA01, LSA02, LSA03, LSA04, LSA05, LSA06 | Background demand |
| EMO / Y | EMO01 through EMO09 inclusive | Sole outcome: later exhaustion |

Evidence: published measurement dictionary, Supplement Tables 14 (pp. 26–27), 21 (p. 32), 22/24 (pp. 33–34), and validation R v2 lines 146–167 and 322–324. Published English wording is in the dictionary; the actual German item text is not supplied. Source-described translation/back-translation is not a fresh validation here.

NON concerns necessary technologies, adequate technologies, and rights to technologies needed for work. PER concerns professional performance/achievements being observed, compared and assessed, including discoverability of mistakes. IOP explicitly concerns privacy compromise through tracking and tracing. These meanings justify the contrast; PER is not objective punitive monitoring, IOP is not a direct measure of job control, and NON is not an inventory of actual equipment. Their conjunction does not directly measure evaluative vulnerability.

Stressor items use 0–4 agreement coding; all items retain the published direction. Exhaustion also has documented 0–4 coding in validation code, but its exact anchors/recall period are unspecified. Therefore Y is a mean endorsement score for the nine published exhaustion items. Do not import the original MBI 0–6 frequency scale, diagnostic categories, or a clinical interpretation. Do not reverse UNR, NON or LSA merely because wording includes negation.

## MAP-01 resolved without using outcomes

The parsimonious source descriptive block substitutes five codes relative to Supplement Table 17 and the validation CFA/SEM. Table 17, Table 21 and Table 26 plus repeated CFA/SEM strings support the published short definition. The present full-scale decision uses all extensive items, so it neither adopts the erroneous descriptive subset nor chooses the better-fitting short subset. No short-scale result is part of the focal analysis. Splitting the two-item short surveillance scale into single-item PER and IOP would change reliability and construct coverage and is not an equivalent replication.

XW-01 remains applicable: sample-3 IOP02–04 are renumbered in benchmarking; no other sample is used. IDs are only within-file keys. Neither code similarity nor common parent study authorizes pooling.

## Scoring, scaling and missingness

Primary eligibility requires every one of the 60 items above, age, and a usable gender category. Each scale score is the mean of all its items. Z-standardize each of the 12 stressor means and the exhaustion mean in this eligible sample using the sample mean and sample SD (denominator n−1). Do not standardize individual items before averaging. Use the same means/SDs in all fixed-sample primary comparisons. In the prespecified paired bootstrap, resample people and recompute scale standardization to account for estimated scaling. Original 0–4 means and SDs will also be reported.

No score imputation is used in the primary analysis. This defines an association among complete measured follow-up respondents, not a claim about all originally recruited workers. If missingness exists, report its patterns and losses and execute the prespecified prorating sensitivity: at least ceiling(0.8×item count) observed items in **each** scale, averaging observed items, with complete age/gender. This means 3/3 for IOP, 5/6 for NON and PER, and 8/9 for EMO. Apply the same rule to all background scales. Repeat all model/scaling steps in that sensitivity cohort. It is a scoring/selection sensitivity, not proof of missing-at-random validity. No claims recover baseline attriters; their data are not established in the release.

Only empty fields and the exact token `NA` are recognized as missing at initial import. Any other nonnumeric item code, noninteger observed item value, or value outside 0–4 is an unresolved source discrepancy: stop dependent scoring and document it. Do not guess a sentinel or recode to zero. A zero is a valid response. A missing item is not evidence of careless responding.

## Demographics and validity limits

Age is in years; model (age−sample mean)/10 and its square. Gender uses the released label field and its verified one-to-one numeric/label mapping, never guessed binary numeric coding. Male is the reference if present; otherwise use lexicographic first nonmissing label. Keep other documented categories distinct in the model. Unknown or contradictory mappings require source resolution before a primary run. Gender categories with no observations create no model columns. Education, work hours, digital-use frequency and their labels are not analysis covariates; variable-specific timing is not established and they add no necessary definition to the selected contrast. Demographics are descriptive adjustment, not a claimed sufficient causal adjustment set.

Report full-scale alpha and interscale correlations descriptively, including PER–IOP separation. Do not use arbitrary alpha thresholds or fit indices to select a different scale/model. Differential reliability and construct overlap are conclusion-changing limitations. The source reports high internal consistency for these three full scales (Supplement Table 24), which supports their use over single short-form items but does not establish error-free or equal measurement. A planned loading-weighted score sensitivity and raw-unit sensitivity are defined in the analysis plan. They do not identify an error-free latent causal effect.

Privacy: keep person IDs only in local validation/lineage, omit them from analysis tables and public files. No raw/derived rows, sparse demographic cross-tabulations, individual residuals, or case-level bootstrap records are distributed. Public outputs are code, source access/hash instructions, plans, and non-identifying aggregate results. No external linkage, reidentification, contact or fresh participant consent collection occurs.
