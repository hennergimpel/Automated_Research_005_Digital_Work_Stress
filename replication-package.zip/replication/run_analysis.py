#!/usr/bin/env python3
"""Frozen observed-score analysis. Only external dependency: NumPy.
All source rows and individual diagnostics remain local. Never runs publisher code.
"""
import os
for _v in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[_v] = '1'
import argparse, collections, csv, datetime, hashlib, io, itertools, json, math
import platform, sys, time, traceback
from pathlib import Path
import numpy as np

SEED=2026102305
B=1999
MIN_VALID=1900
SOURCE_HASH='5709b42c802e07e0eeeecc2e67aa642c31781ff96ec1700ecf1de69ef4d2186b'
PLAN_HASH='d22f2b0d8509c826d61f522b78cb8fa2b51e5a2902c8e31299cb7d65f952aecb'
MEASUREMENT_HASH='9b6aaa32d82ea60b4abd03b0f5f8e3863e420a68f8bc826f238e93735edc2f3e'
PAYLOAD_HASH='4bb007f01cbacad47a9afaa519525edd3dad9ffff32f3b5de489235b32e3dd87'
NAMES=['INV','OVE','COM','INS','UNC','UNR','ROL','IOP','INT','PER','NON','LSA']
COUNTS=[3,4,5,4,4,3,4,3,3,6,6,6]
MAP={s:[f'{s}{i:02}' for i in (range(2,5) if s=='IOP' else range(1,k+1))] for s,k in zip(NAMES,COUNTS)}
MAP['EMO']=[f'EMO{i:02}' for i in range(1,10)]
ITEMS=sum(MAP.values(),[])
PAIRS=list(itertools.combinations(range(12),2))
CUBICS=list(itertools.combinations_with_replacement([10,9,7],3))
WEIGHTS={'NON':[.83,.83,.82,.90,.84,.84],'PER':[.78,.80,.88,.83,.87,.79],'IOP':[.93,.95,.92]}
EXPECTED=['run_analysis.py','README.md','results.json','run_manifest.json','sample_flow.json','tables.csv','numeric_claims.csv','analysis_report.md','result.json']
utc=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def dump(p,x):
    Path(p).parent.mkdir(parents=True,exist_ok=True)
    Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')

def clean(x):
    if isinstance(x,dict): return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [clean(v) for v in x]
    if isinstance(x,np.ndarray): return clean(x.tolist())
    if isinstance(x,np.generic): return clean(x.item())
    if isinstance(x,float) and not math.isfinite(x): return None
    return x

def betacf(a,b,x):
    # Numerical Recipes modified-Lentz continued fraction; used only for t CDF.
    qab=a+b; qap=a+1; qam=a-1; c=1.; d=1-qab*x/qap
    if abs(d)<1e-300: d=1e-300
    d=1/d; h=d
    for m in range(1,501):
        m2=2*m; aa=m*(b-m)*x/((qam+m2)*(a+m2))
        d=1+aa*d; d=1e-300 if abs(d)<1e-300 else d
        c=1+aa/c; c=1e-300 if abs(c)<1e-300 else c
        d=1/d; h*=d*c
        aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2))
        d=1+aa*d; d=1e-300 if abs(d)<1e-300 else d
        c=1+aa/c; c=1e-300 if abs(c)<1e-300 else c
        d=1/d; delta=d*c; h*=delta
        if abs(delta-1)<2e-14: return h
    raise RuntimeError('t-CDF continued fraction failed')

def ibeta(a,b,x):
    if x<=0: return 0.
    if x>=1: return 1.
    bt=math.exp(math.lgamma(a+b)-math.lgamma(a)-math.lgamma(b)+a*math.log(x)+b*math.log1p(-x))
    if x<(a+1)/(a+b+2): return bt*betacf(a,b,x)/a
    return 1-bt*betacf(b,a,1-x)/b

def tcrit(df):
    lo,hi=0.,10.
    for _ in range(70):
        m=(lo+hi)/2; cdf=1-.5*ibeta(df/2,.5,df/(df+m*m))
        if cdf<.975: lo=m
        else: hi=m
    return (lo+hi)/2

def columns(z,age,g,levels,demog=True,functional=False):
    n=len(z); arr=[np.ones(n)]; names=['intercept']
    for j in range(12): arr.append(z[:,j]); names.append(NAMES[j])
    for j in range(12): arr.append(z[:,j]**2); names.append(NAMES[j]+'^2')
    for j,k in PAIRS: arr.append(z[:,j]*z[:,k]); names.append(NAMES[j]+'*'+NAMES[k])
    if demog:
        a=(age-age.mean())/10
        arr.extend([a,a*a]); names.extend(['Age10','Age10^2'])
        for level in levels[1:]: arr.append((g==level).astype(float)); names.append('gender='+level)
    if functional:
        for inds in CUBICS:
            arr.append(np.prod(z[:,inds],axis=1)); names.append('*'.join(NAMES[j] for j in inds))
        t=z.mean(axis=1); arr.extend([t**3,t**4]); names.extend(['T^3','T^4'])
    return np.column_stack(arr),names

def contrasts(names,demog,functional):
    # Exact finite contrasts at fixed standardized profiles, common age/reference gender.
    if not functional:
        c=np.zeros((2,len(names)))
        c[0,names.index('PER*NON')]=1
        c[1,names.index('PER*NON')]=1
        c[1,names.index('IOP*NON')]=-1
        return c
    z=np.zeros((8,12)); weights=np.array([1,-1,-1,1])
    z[:4,10]=[.5,.5,-.5,-.5]; z[:4,9]=[.5,-.5,.5,-.5]
    z[4:,10]=[.5,.5,-.5,-.5]; z[4:,9]=[.5,-.5,.5,-.5]; z[4:,7]=[-.5,.5,-.5,.5]
    # Build profile polynomial columns directly; demographic entries all zero except intercept.
    x,_=columns(z,np.zeros(8),np.array(['reference']*8),['reference'],demog,functional)
    # No gender indicator at reference; append/map by names to the original basis.
    xn=columns(z,np.zeros(8),np.array(['reference']*8),['reference'],demog,functional)[1]
    xp=np.zeros((8,len(names)))
    for j,name in enumerate(xn): xp[:,names.index(name)]=x[:,j]
    return np.vstack([weights@xp[:4],weights@xp[4:]])

def design(scores,yraw,age,g,levels,variant):
    sm=scores.mean(axis=0); ss=scores.std(axis=0,ddof=1); ym=yraw.mean(); ys=yraw.std(ddof=1)
    if np.any(ss<=0) or ys<=0 or not np.isfinite(ss).all() or not np.isfinite(ys): raise ValueError('zero_or_invalid_scale_sd')
    z=(scores-sm)/(1 if variant=='units' else ss)
    demog=variant!='no_demographics'; functional=variant=='functional_form'
    x,names=columns(z,age,g,levels,demog,functional)
    c=contrasts(names,demog,functional)
    return x,(yraw-ym)/ys,c,names,{'stressor_means':sm,'stressor_sds':ss,'outcome_mean':ym,'outcome_sd':ys,'age_mean':age.mean()}

def fit(x,y,c,full=False):
    # SVD of the actual design, no squared-condition normal-equation fitting.
    # Omit all-zero absent-category nuisance columns but retain all polynomial terms.
    keep=~np.all(x==0,axis=0); xx=x[:,keep]; cc=c[:,keep]
    u,s,vt=np.linalg.svd(xx,full_matrices=False)
    tol=max(xx.shape)*np.finfo(float).eps*s[0]; good=s>tol; rank=int(good.sum())
    v=vt[good].T; uu=u[:,good]; sv=s[good]
    projection=cc@v@v.T
    if np.max(np.abs(cc-projection))>1e-8: raise ValueError('target_not_estimable')
    beta=v@((uu.T@y)/sv); est=cc@beta
    if not full: return est
    residual=y-xx@beta; leverage=np.sum(uu**2,axis=1); df=len(y)-rank
    if df<200: raise ValueError('residual_df_below_200')
    if leverage.max()>=.99: raise ValueError('leverage_at_least_099')
    # Contrasts of HC3 sandwich without constructing the full p by p covariance.
    pinv=(v/sv)@uu.T; cp=cc@pinv
    cov=(cp*(residual/(1-leverage)))@(cp*(residual/(1-leverage))).T
    unscaled=cp@cp.T; se=np.sqrt(np.diag(cov)); critical=tcrit(df)
    scale=xx.std(axis=0,ddof=1); scale[0]=1
    xs=xx/scale; condition=float(np.linalg.cond(xs))
    if condition>1e8: raise ValueError('scaled_condition_gt_1e8_requires_independent_check')
    bfull=np.zeros(x.shape[1]); bfull[keep]=beta
    return {'estimate':est,'rank':rank,'columns':x.shape[1],'effective_columns':xx.shape[1], 'df_residual':df,'HC3_covariance':cov,'HC3_se':se,'HC3_ci95':np.column_stack([est-critical*se,est+critical*se]),'t_critical_975':critical,'scaled_condition_number':condition,'contrast_unscaled_covariance':unscaled,'residualized_contrast_information':1/np.diag(unscaled),'leverage':leverage,'residual':residual,'fitted':y-residual,'beta':bfull,'R_squared':1-float(residual@residual/(y@y)),'design_rank_deficient':rank<xx.shape[1]}

def classify(gamma_ci,theta_ci,theta90,units=False):
    h1=bool(gamma_ci[0]>0 and theta_ci[0]>0)
    return {'H1_supported':h1,'consequential_specificity':None if units else bool(theta_ci[0]>.20 and gamma_ci[0]>0),'against_materially_positive_specificity':None if units else bool(theta_ci[1]<.20),'equivalent_within_020':None if units else bool(theta90[0]>-.20 and theta90[1]<.20),'contrary_ordering':bool(theta_ci[1]<0),'directional_status':'supported' if h1 else ('contrary_ordering' if theta_ci[1]<0 else 'inconclusive'),'margin_applied':not units}

def validate(data):
    raw=Path(data).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=SOURCE_HASH: raise ValueError('Source hash mismatch before parsing')
    started=utc(); reader=csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))); rows=list(reader)
    hdr=reader.fieldnames
    if len(rows)!=1560 or len(hdr)!=71 or len(set(hdr))!=71: raise ValueError('source dimension discrepancy')
    required=ITEMS+['id','age','gender','gender_label','age_label','education','education_label','extent_of_work','extent_of_work_label','dig_tech_use','dig_tech_use_label']
    if set(required)!=set(hdr): raise ValueError('documented source field discrepancy: '+str(sorted(set(required)^set(hdr))))
    ids=[r['id'] for r in rows]
    if any(v in ('','NA') for v in ids) or len(set(ids))!=len(rows): raise ValueError('missing_or_duplicate_ID')
    if any(not float(v).is_integer() for v in ids): raise ValueError('noninteger_ID')
    a=np.full((len(rows),60),np.nan); ages=np.full(len(rows),np.nan); genders=[]; mapping={}; missing_gender=0
    for i,r in enumerate(rows):
        for j,k in enumerate(ITEMS):
            val=r[k]
            if val in ('','NA'): continue
            try: f=float(val)
            except ValueError: raise ValueError('unexpected_item_code:'+k)
            if not math.isfinite(f) or not f.is_integer() or not 0<=f<=4: raise ValueError('invalid_item_value:'+k)
            a[i,j]=f
        if r['age'] not in ('','NA'):
            ages[i]=float(r['age'])
            if not math.isfinite(ages[i]) or not 0<=ages[i]<=120: raise ValueError('invalid_age')
            if ages[i]<18: raise ValueError('adult_employment_age_inconsistency_requires_resolution')
        code,label=r['gender'],r['gender_label']
        if code in ('','NA') or label in ('','NA'):
            genders.append(''); missing_gender+=1; continue
        if not math.isfinite(float(code)): raise ValueError('invalid_gender_numeric')
        normalized=label.casefold().strip()
        if normalized not in ('male','female','other or not-disclosed','other or not disclosed','other/not disclosed'):
            raise ValueError('undocumented_gender_category:'+label)
        if code in mapping and mapping[code]!=label: raise ValueError('inconsistent_gender_mapping')
        mapping[code]=label; genders.append(label)
    if len(set(mapping.values()))!=len(mapping): raise ValueError('non_one_to_one_gender_mapping')
    g=np.array(genders); eligible=np.isfinite(a).all(axis=1)&np.isfinite(ages)&(g!='')
    flow={'exposure_and_profiling_start_utc':started,'n_release':len(rows),'n_fields':len(hdr),'unique_nonmissing_ids':True,'validation_status':'passed','item_missing_cells':int(np.isnan(a).sum()),'item_incomplete_rows':int(np.isnan(a).any(axis=1).sum()),'missing_age':int(np.isnan(ages).sum()),'missing_gender':missing_gender,'complete_items':int(np.isfinite(a).all(axis=1).sum()),'n_primary':int(eligible.sum()),'n_missing_excluded':int((~eligible).sum()),'missing_by_item':{k:int(np.isnan(a[:,j]).sum()) for j,k in enumerate(ITEMS)},'item_missing_count_distribution':{str(int(k)):int(v) for k,v in zip(*np.unique(np.isnan(a).sum(axis=1),return_counts=True))},'gender_numeric_label_mapping':mapping,'age_min':float(np.nanmin(ages)),'age_max':float(np.nanmax(ages)),'baseline_recruited_denominator':None,'followup_attrition_rate':None,'baseline_attrition_reason':'Not established in release; no rate inferred','validation_completed_utc':utc()}
    return a,ages,g,eligible,flow

def scores_for(a,weighted=False,prorate=False):
    vals=[]; ok=np.ones(len(a),dtype=bool); start=0
    for name,items in MAP.items():
        aa=a[:,start:start+len(items)]; start+=len(items)
        observed=np.isfinite(aa).sum(axis=1)
        ok&=observed>=(math.ceil(.8*len(items)) if prorate else len(items))
        if weighted and name in WEIGHTS: score=aa@np.array(WEIGHTS[name])/sum(WEIGHTS[name])
        else: score=np.nansum(aa,axis=1)/np.maximum(observed,1)
        vals.append(score)
    return np.column_stack(vals)[:,:12],vals[-1],ok

def distribution(x):
    return {'mean':float(np.mean(x)),'sd':float(np.std(x,ddof=1)),'min':float(np.min(x)),'max':float(np.max(x)),'quantiles_0_25_50_75_100':np.quantile(x,[0,.25,.5,.75,1],method='linear').tolist(),'skewness_moment':float(np.mean(((x-x.mean())/x.std(ddof=0))**3))}

def alpha(a):
    k=a.shape[1]; totalvar=np.var(a.sum(axis=1),ddof=1)
    return float(k/(k-1)*(1-np.var(a,axis=0,ddof=1).sum()/totalvar)) if totalvar>0 else None

def support_stats(scores):
    z=(scores-scores.mean(axis=0))/scores.std(axis=0,ddof=1); A,M,P=z[:,10],z[:,9],z[:,7]
    cubes=[]; back=[j for j in range(12) if j not in [10,9,7]]
    for side in ['low','high']:
        ma=((A>=-1)&(A<0)) if side=='low' else ((A>=0)&(A<=1))
        for profile in ['monitoring_high','privacy_high']:
            mp=((M>=0)&(M<=1)&(P>=-1)&(P<0)) if profile=='monitoring_high' else ((M>=-1)&(M<0)&(P>=0)&(P<=1))
            mask=ma&mp; zz=z[mask]; n=int(mask.sum())
            cubes.append({'cube':side+'_'+profile,'n':n,'background_standardized_ranges':{NAMES[j]:[float(zz[:,j].min()),float(zz[:,j].max())] if n else None for j in back},'background_means_in_whole_cohort_SD_units':{NAMES[j]:float(zz[:,j].mean()) if n else None for j in back}})
    diffs={}
    for i,j in itertools.combinations(range(4),2): diffs[cubes[i]['cube']+' minus '+cubes[j]['cube']]={k:cubes[i]['background_means_in_whole_cohort_SD_units'][k]-cubes[j]['background_means_in_whole_cohort_SD_units'][k] for k in cubes[i]['background_means_in_whole_cohort_SD_units']} if cubes[i]['n'] and cubes[j]['n'] else None
    return {'cubes':cubes,'all_four_cubes_at_least_25':all(c['n']>=25 for c in cubes),'background_pairwise_standardized_mean_differences':diffs,'focal_correlation_order':['NON','PER','IOP'],'focal_correlation':np.corrcoef(z[:,[10,9,7]],rowvar=False),'focal_standardized_ranges':{NAMES[j]:[z[:,j].min(),z[:,j].max()] for j in [10,9,7]},'support_limit':'Counts cover only focal three dimensions, not conditional overlap in all demands or exchangeability.'}

def density_svg(path,x,y,xlabel,ylabel):
    # Nonidentifying binned distribution; no plotted individual coordinates or IDs.
    h,xe,ye=np.histogram2d(x,y,bins=40); mx=h.max(); w=640; ht=440
    parts=['<svg xmlns="http://www.w3.org/2000/svg" width="760" height="540" viewBox="0 0 760 540">','<rect width="760" height="540" fill="white"/>']
    for i,j in zip(*np.nonzero(h)):
        opacity=.15+.85*math.log1p(h[i,j])/math.log1p(mx)
        parts.append(f'<rect x="{70+i*w/40:.2f}" y="{30+(39-j)*ht/40:.2f}" width="{w/40:.2f}" height="{ht/40:.2f}" fill="#275b92" opacity="{opacity:.4f}"/>')
    parts.extend([f'<rect x="70" y="30" width="640" height="440" fill="none" stroke="black"/>',f'<text x="350" y="515" font-size="16">{xlabel}</text>',f'<text x="10" y="20" font-size="16">{ylabel}</text>',f'<text x="70" y="490" font-size="12">{xe[0]:.3f}</text>',f'<text x="660" y="490" font-size="12">{xe[-1]:.3f}</text>',f'<text x="15" y="470" font-size="12">{ye[0]:.3f}</text>',f'<text x="15" y="45" font-size="12">{ye[-1]:.3f}</text>','</svg>'])
    Path(path).write_text('\n'.join(parts),encoding='utf-8')

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    root=Path(__file__).resolve().parent
    provenance=json.loads((root/'provenance.json').read_text(encoding='utf-8'))
    input_info=[]
    for name,expected in provenance['required_public_files'].items():
        p=root/name
        if sha(p)!=expected: raise ValueError('Public file integrity mismatch: '+name)
        input_info.append({'path':name,'sha256':expected,'bytes':p.stat().st_size})
    assert provenance['source']['sha256']==SOURCE_HASH
    assert provenance['frozen_ancestry']['analysis_plan_sha256']==PLAN_HASH
    assert provenance['frozen_ancestry']['measurement_sha256']==MEASUREMENT_HASH
    assert provenance['frozen_ancestry']['initial_payload_sha256']==PAYLOAD_HASH
    out=args.output.resolve(); out.mkdir(parents=True,exist_ok=True); support=out/'support'; support.mkdir(exist_ok=True)
    if (out/'results.json').exists(): raise SystemExit('Refuse to overwrite completed results; select a new output directory.')
    start=utc(); run_id='T008_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    manifest={'run_id':run_id,'status':'running','started_utc':start,'script_sha256':sha(__file__),'source_sha256':sha(args.data),'source_bytes':args.data.stat().st_size,'plan_sha256':PLAN_HASH,'payload_sha256':PAYLOAD_HASH,'measurement_sha256':MEASUREMENT_HASH,'public_provenance_sha256':sha(root/'provenance.json'),'inputs':input_info,'command_template':'python run_analysis.py --data <pinned CSV> --output <fresh directory>','python':sys.version,'numpy':np.__version__,'platform':platform.system()+' '+platform.release(),'seed':SEED,'generator':'numpy.random.default_rng / PCG64; reinitialized same seed per variant','bootstrap_draws':B,'minimum_valid_draws':MIN_VALID,'quantiles':'numpy.quantile(method=linear), equivalent R type=7','SD_denominator':'n-1','linear_algebra':'NumPy SVD actual design; tolerance max(n,p)*eps*s_max; target row-space check absolute 1e-8','HC3_t_quantile':'Student t inverse via incomplete beta modified-Lentz continued fraction and bisection; no SciPy dependency','threads':{v:os.environ[v] for v in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']},'warnings':[],'deviations':[],'source_R_executed':False,'new_hypotheses':False}
    dump(out/'run_manifest.json',manifest)
    a,age,g,eligible,flow=validate(args.data); dump(out/'sample_flow.json',flow)
    print(json.dumps({'event':'validation_complete','n_primary':flow['n_primary'],'missing_item_rows':flow['item_incomplete_rows'],'utc':utc()}),flush=True)
    s,y,_=scores_for(a); sw,yw,_=scores_for(a,weighted=True)
    levels=sorted(set(g[eligible])); male=[v for v in levels if v.lower()=='male']
    if male: levels=male+[v for v in levels if v!=male[0]]
    manifest['profiling_start_utc']=flow['exposure_and_profiling_start_utc']; manifest['test_run_start_utc']=utc()
    result={'schema_version':'1.0','run_id':run_id,'contrast_order':['gamma','theta'],'n_release':len(a),'n_primary':int(eligible.sum()),'n_missing_excluded':int((~eligible).sum()),'plan_sha256':PLAN_HASH,'source_sha256':SOURCE_HASH,'gender_levels_reference_first':levels,'analyses':{},'warnings':[],'deviations':[],'interpretation_scope':'Between-person lagged observed-score conditional associations. No causal change, accountability identification, exclusion of unequal-weight burden or error-free latent inference.'}
    primary_h=None
    variants=['primary','units','published_loadings','functional_form','influence','no_demographics']
    if flow['item_incomplete_rows']: variants.append('prorating')
    else: result['analyses']['prorating']={'status':'not_applicable','reason':'No item-incomplete respondents in released data; conditional trigger false.'}
    for variant in variants:
        vstart=utc(); mask=eligible.copy(); sx,yy=(sw,yw) if variant=='published_loadings' else (s,y)
        if variant=='influence':
            remove=primary_h>3*result['analyses']['primary']['rank']/int(eligible.sum())
            mask[np.flatnonzero(eligible)[remove]]=False
        if variant=='prorating':
            sx,yy,ok=scores_for(a,prorate=True); mask=ok&np.isfinite(age)&(g!='')
        ss=sx[mask]; ys=yy[mask]; aa=age[mask]; gg=g[mask]; n=len(ss)
        try:
            x,zy,c,names,scaling=design(ss,ys,aa,gg,levels,variant)
            f=fit(x,zy,c,full=True)
            if variant=='primary': primary_h=f['leverage'].copy()
            res={'status':'running','started_utc':vstart,'n':n,'excluded_from_primary':int(eligible.sum()-n),'rank':f['rank'],'columns':f['columns'],'effective_columns':f['effective_columns'],'df_residual':f['df_residual'],'design_rank_deficient':f['design_rank_deficient'],'gamma':float(f['estimate'][0]),'theta':float(f['estimate'][1]),'HC3_covariance':f['HC3_covariance'],'HC3_se':f['HC3_se'],'HC3_ci95':f['HC3_ci95'],'HC3_t_critical_975':f['t_critical_975'],'scaled_condition_number':f['scaled_condition_number'],'contrast_unscaled_covariance':f['contrast_unscaled_covariance'],'residualized_contrast_information':f['residualized_contrast_information'],'leverage_summary':{'min':float(f['leverage'].min()),'max':float(f['leverage'].max()),'mean':float(f['leverage'].mean()),'quantiles_50_90_95_99':np.quantile(f['leverage'],[.5,.9,.95,.99]),'threshold_3p_over_n':3*f['rank']/n,'n_above_threshold':int(np.sum(f['leverage']>3*f['rank']/n))},'scaling':scaling,'R_squared':f['R_squared'],'bootstrap':{'requested_draws':B,'seed':SEED,'completed_draws':0},'units':'outcome SD per response-unit mixed difference' if variant=='units' else 'outcome SD per standardized profile contrast','feature_names':names,'contrast_vectors':c,'coefficients':f['beta']}
            fitted_raw=f['fitted']*scaling['outcome_sd']+scaling['outcome_mean']
            res['predictions_original_exhaustion_units']={'min':float(fitted_raw.min()),'max':float(fitted_raw.max()),'n_below_0':int((fitted_raw<0).sum()),'n_above_4':int((fitted_raw>4).sum())}
            if variant=='primary':
                result['descriptives']={name:distribution(np.column_stack([ss,ys])[:,j]) for j,name in enumerate(NAMES+['EMO'])}
                result['support']=support_stats(ss)
                result['interscale_correlation_order']=NAMES+['EMO']; result['interscale_correlations']=np.corrcoef(np.column_stack([ss,ys]),rowvar=False)
                result['PER_IOP_correlation']=float(np.corrcoef(ss[:,9],ss[:,7])[0,1])
                offset=0; reliabilities={}
                for name,items in MAP.items(): reliabilities[name]=alpha(a[eligible,offset:offset+len(items)]); offset+=len(items)
                result['Cronbach_alpha']=reliabilities
                density_svg(support/'primary_residual_vs_fitted.svg',f['fitted'],f['residual'],'Fitted exhaustion (SD)','Residual (SD)')
                density_svg(support/'primary_observed_vs_fitted.svg',f['fitted'],zy,'Fitted exhaustion (SD)','Observed exhaustion (SD)')
            rng=np.random.default_rng(SEED); draws=[]; failures=collections.Counter(); draws_with_index=[]
            for b in range(B):
                ix=rng.integers(0,n,n)
                try:
                    bx,by,bc,_,_=design(ss[ix],ys[ix],aa[ix],gg[ix],levels,variant)
                    be=fit(bx,by,bc)
                    if not np.isfinite(be).all(): raise ValueError('nonfinite_estimate')
                    draws.append(be); draws_with_index.append([b+1,float(be[0]),float(be[1])])
                except (ValueError,np.linalg.LinAlgError) as exc: failures[str(exc)]+=1
                if (b+1)%250==0 or b+1==B:
                    print(json.dumps({'event':'bootstrap_checkpoint','variant':variant,'completed':b+1,'valid':len(draws),'utc':utc()}),flush=True)
                    dump(support/(variant+'_checkpoint.json'),{'run_id':run_id,'analysis':variant,'completed':b+1,'valid':len(draws),'invalid_reasons':dict(failures),'utc':utc()})
            dv=np.array(draws)
            res['bootstrap']={'requested_draws':B,'completed_draws':B,'valid_draws':len(draws),'invalid_draws':B-len(draws),'invalid_reasons':dict(failures),'seed':SEED,'resample_size':n,'standardization_reestimated':True,'age_center_reestimated':True,'gender_levels_fixed':levels,'quantile_method':'linear / R type 7','minimum_valid':MIN_VALID,'draw_estimates_path':'support/'+variant+'_bootstrap_contrasts.csv'}
            with (support/(variant+'_bootstrap_contrasts.csv')).open('w',encoding='utf-8',newline='') as fp:
                writer=csv.writer(fp); writer.writerow(['draw','gamma','theta']); writer.writerows(draws_with_index)
            if len(draws)>=MIN_VALID:
                ci95=np.quantile(dv,[.025,.975],axis=0,method='linear').T; ci90=np.quantile(dv,[.05,.95],axis=0,method='linear').T
                res.update({'status':'complete','bootstrap_ci95':ci95,'bootstrap_ci90':ci90,'bootstrap_covariance':np.cov(dv,rowvar=False,ddof=1),'bootstrap_ci95_width':ci95[:,1]-ci95[:,0],'classification':classify(ci95[0],ci95[1],ci90[1],variant=='units')})
            else: res.update({'status':'bootstrap_failed','reason':'Fewer than 1900 valid draws; HC3 sensitivity only, primary classification unavailable.'})
            res['completed_utc']=utc(); result['analyses'][variant]=clean(res)
        except (ValueError,np.linalg.LinAlgError) as exc:
            result['analyses'][variant]={'status':'failed','reason':str(exc),'n':n,'started_utc':vstart,'completed_utc':utc()}
            if variant=='primary': raise
        dump(support/(variant+'_result.json'),clean(result['analyses'][variant]))
        dump(support/'results_checkpoint.json',clean(result))
    primary=result['analyses']['primary']; sign_reversals=[]
    for v,r in result['analyses'].items():
        if v not in ('primary','prorating') and 'theta' in r:
            if primary['theta']*r['theta']<0: sign_reversals.append(v+':theta')
            if primary['gamma']*r['gamma']<0: sign_reversals.append(v+':gamma')
        if v=='prorating' and 'theta' in r:
            if primary['theta']*r['theta']<0: sign_reversals.append(v+':theta')
            if primary['gamma']*r['gamma']<0: sign_reversals.append(v+':gamma')
    func=result['analyses']['functional_form']; function_h1_failure=not func.get('classification',{}).get('H1_supported',False)
    result['fragility']={'sign_reversals':sign_reversals,'functional_form_H1_not_supported':function_h1_failure,'support_failed':not result['support']['all_four_cubes_at_least_25'],'theoretical_interpretation_fragile':bool(sign_reversals or function_h1_failure or not result['support']['all_four_cubes_at_least_25'])}
    result['completed_utc']=utc(); dump(out/'results.json',clean(result)); rh=sha(out/'results.json')
    rows=[]
    for v,r in result['analyses'].items():
        if 'theta' not in r: rows.append({'analysis':v,'quantity':'status','value':r['status'],'lower95':'','upper95':'','lower90':'','upper90':'','n':r.get('n',''),'valid_draws':'','result_key':'analyses.'+v+'.status'}); continue
        for j,k in enumerate(['gamma','theta']):
            c95=r.get('bootstrap_ci95',[[None,None]]*2)[j]; c90=r.get('bootstrap_ci90',[[None,None]]*2)[j]
            rows.append({'analysis':v,'quantity':k,'value':r[k],'lower95':c95[0],'upper95':c95[1],'lower90':c90[0],'upper90':c90[1],'n':r['n'],'valid_draws':r['bootstrap']['valid_draws'],'result_key':'analyses.'+v+'.'+k})
    with (out/'tables.csv').open('w',newline='',encoding='utf-8') as fp:
        w=csv.DictWriter(fp,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    claims=[]
    def flatten(x,path=''):
        if isinstance(x,dict):
            for k,v in x.items(): flatten(v,path+'.'+k if path else k)
        elif isinstance(x,list):
            for j,v in enumerate(x): flatten(v,path+f'.{j}')
        elif isinstance(x,(float,int)) and not isinstance(x,bool): claims.append({'claim_id':f'T008_NUM_{len(claims)+1:05}','run_id':run_id,'result_file':'results.json','result_sha256':rh,'result_key':path,'exact_value':x,'display_6dp':f'{x:.6f}' if isinstance(x,float) else str(x),'rounding':'nearest, Python format .6f for real-valued display; integers exact'})
    flatten(clean(result))
    with (out/'numeric_claims.csv').open('w',newline='',encoding='utf-8') as fp:
        w=csv.DictWriter(fp,fieldnames=list(claims[0])); w.writeheader(); w.writerows(claims)
    report=['# Replication results','',f'Run {run_id}. Results SHA-256: {rh}. See numeric_claims.csv for exact result keys and values.','', '| Analysis | n | gamma | theta | valid draws |','|---|---:|---:|---:|---:|']
    for v,r in result['analyses'].items():
        if 'theta' in r: report.append(f"| {v} | {r['n']} | {r['gamma']:.6f} | {r['theta']:.6f} | {r['bootstrap']['valid_draws']} |")
        else: report.append(f"| {v} | {r['status']} | | | |")
    report+=['', 'Primary classification: '+json.dumps(primary.get('classification',{}),sort_keys=True), '', 'Fragility: '+json.dumps(result['fragility'],sort_keys=True), '', 'All intervals, classifications, diagnostics and support are in results.json. The conjunction is not supported in the accepted primary analysis; evidence against material positive specificity does not establish equivalence. Between-person lagged conditional associations do not identify a causal mechanism, accountability, change or error-free latent constructs. See SCIENTIFIC_SPEC.md and SOURCE.md in the package.']
    (out/'analysis_report.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
    manifest.update({'status':'complete','completed_utc':utc(),'results_sha256':rh,'all_sensitivity_statuses':{v:r['status'] for v,r in result['analyses'].items()},'no_processed_rows_written':True,'files':{str(p.relative_to(out)).replace('\\','/'):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='run_manifest.json'}})
    dump(out/'run_manifest.json',clean(manifest))
    print(json.dumps({'event':'complete','run_id':run_id,'results_sha256':rh,'utc':utc()}),flush=True)

if __name__=='__main__': main()
